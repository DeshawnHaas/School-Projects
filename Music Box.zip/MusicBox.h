//Name: MusicBox.h
//Author: Deshawn Haas
//Date: 11/6/2023
/*Description: This class usees a doubly linked list to create a music playlist that stores a song. Each song consists of a duration and a title. The class uses 
the doubly linked list to navigate the playlist that it created. */

#include <iostream>
#include "DoublyLinkedList.h"
#ifndef MUSIC_BOX_H
#define MUSIC_BOX_H
using namespace std;

struct Song
{
    string title;
    int duration;
    Song(const string& _title, int _duration);      //Song constructor

    // Overloaded equal operator to compare songs together
    bool operator==(const Song& other) const
    {
        return title == other.title;
    }

};

class MusicBox
{
    private:
        DoublyLinkedList<Song> playlist;    // Doubly Linked List for songs
        int currentSongIndex;               // Index to keep track of which songs playing
    public:
        MusicBox();                                         // Constructor
        void addSong(const string& _title, int _duration);  // Add's a song to the playlist
        bool removeSong(const string& _title);              // Removee's a song from the playlist
        void searchSong(const string& _title);              // Search's song from the playlist and returns if it is in it
        void playNext();                                    // Play's the next song in the playlist
        void playPrevious();                                // Play's the previous song in the playlist
        void currentSong();                                 // Display's the current song
        void displayPlaylist();                             // Show's every song that is currently in the playlist
        Song getSong();                                     // Find's the current song
        void sort();                                        // Use's a quick sort algorithm to sort from the initial song as a pivot
};

// Constructs an empty Song
Song::Song(const string& _title, int _duration) : title(_title), duration(_duration) 
{

}

// Constructs an empty music box with the current song index set to -1 to show empty
MusicBox::MusicBox() : currentSongIndex(-1)
{

}

void MusicBox::addSong(const string& _title, int _duration)
{
    Song newSong(_title, _duration);    // Create's new song
    playlist.push_back(newSong);        // Add's the song to the playlist
    if (currentSongIndex == -1)         // Situation for if there are no songs in playlist
    {
        currentSongIndex = 0;
    }
    cout << _title << " added to the playlist." << endl;

}

bool MusicBox::removeSong(const string& _title)
{
    for (int i = 0; i < playlist.getSize(); i++)        // Iterates through the playlist
    {
        if(playlist.at(i).title == _title)              // Checks to see if the title matches one in the playlist
        {
            if (i == currentSongIndex)                  // Update's current song index if the song is current
            {
                currentSongIndex = (currentSongIndex + 1) % playlist.getSize();
            }
            playlist.remove(playlist.at(i));            // Removes the song
            cout << _title << " removed from the playlist." << endl;
            return true;
        }
    }
    cout << "Song not found in playlist" << endl;
    return false;
}

void MusicBox::searchSong(const string& _title)
{
    for (int i = 0; i < playlist.getSize(); i++)        // Iterates through the list
    {
        if (playlist.at(i).title == _title)             // Ensures the titles match
        {
        cout << "Song found in playlist" << endl;       // Pritns if found
            return;
        }
    }
    cout << "Song not found in playlist" << endl;       // Prints if not found
}

void MusicBox::playNext() 
{
    if(playlist.getSize() == 0)     // Condition if paylist is empty
    {
        cout << "No songs in the playlist." << endl;
        return;
    }
    currentSongIndex = (currentSongIndex + 1) % playlist.getSize(); // Changes song index to reflect next song
    currentSong();      // Displays the current song
}

void MusicBox::playPrevious() 
{
    if (playlist.getSize() == 0)    // Condition to see if playlist is empty
    {
        cout << "No songs in the playlist." << endl;
        return;
    }
    if (currentSongIndex == 0)      // If this is the first song in the playlist it will loop to the last song in the playlist
    {
        currentSongIndex = playlist.getSize() - 1;
    } 
    else 
    {
        currentSongIndex = (currentSongIndex - 1) % playlist.getSize();     // Moves to previous song
    }
    currentSong();      // Displays current song
}

void MusicBox::currentSong()
{
    Song current = getSong();
    cout << "Now playing: " << current.title << " Duration: " << current.duration << " seconds." << endl;

}

Song MusicBox::getSong() 
{
    if (currentSongIndex >= 0 && currentSongIndex < playlist.getSize())     // Ensuers that there is a current song
    {
        return playlist.at(currentSongIndex);
    } 
    else 
    {
        return Song("", 0);     // Returns empty song if none found
    }
}

void MusicBox::displayPlaylist() 
{
    cout << "Playlist:" << endl;
    for (int i = 0; i < playlist.getSize(); ++i)    // Iterates through playlist
    {
        Song song = playlist.at(i);     // Collects the song at each index
        cout << song.title << " - " << song.duration << " seconds" << endl;     // Displays each song
    }
}

void quicksort(DoublyLinkedList<Song>& list) 
{
    if (list.getSize() <= 1) 
    {
        return; // Don'tneed to sort an empty or single-song list.
    }
    Song pivot = list.at(0);
    DoublyLinkedList<Song> lessThanPivot;
    DoublyLinkedList<Song> greaterThanPivot;
    
     // Partition the list into sub-lists.
    for (int i = 1; i < list.getSize(); i++)
    {
        if (list.at(i).title < pivot.title) 
        {
            lessThanPivot.push_back(list.at(i));
        } 
        else 
        {
            greaterThanPivot.push_back(list.at(i));
        }
    }

    // Recursively sort the sub-lists.
    quicksort(lessThanPivot);    // Sort songs less than the pivot.
    quicksort(greaterThanPivot); // Sort songs greater than the pivot.

    // Clear the current list by iteratively removing elements.
    while (list.getSize() > 0) 
    {
        list.remove(list.at(0));
    }

    // Reassemble the list with the sorted sub-lists.
    for (int i = 0; i < lessThanPivot.getSize(); i++) 
    {
        list.push_back(lessThanPivot.at(i));
    }
   
    list.push_back(pivot);
    
    for (int i = 0; i < greaterThanPivot.getSize(); i++) 
    {
        list.push_back(greaterThanPivot.at(i));
    }
}

void MusicBox::sort() 
{
    quicksort(playlist);

    for (int i = 0; i < playlist.getSize(); i++) 
    {
        if (playlist.at(i) == playlist.at(0)) 
        {
            // Updates the current song index to the first song of the sorted list
            currentSongIndex = i;
            break;
        }
    }
    cout << "Playlist has been sorted." << endl;
}
#endif