//Name: DoublyLinkedList.h
//Author: Deshawn Haas
//Date: 11/6/2023
//Description: This class creates a doubly linked list that utilizes head, tail, next, and previous pointers to manage and manipulate data.
#include <iostream>
#ifndef DOUBLY_LINKED_LIST_H
#define DOUBLY_LINKED_LIST_H

template <class T> 
struct Node
{
    T data;         
    Node* next;     
    Node* previous;
    Node(const T& _data) : data(_data), next(nullptr), previous(nullptr) {}
};  

template <class T>
class DoublyLinkedList
{
private:
    Node<T>* head;      // Points to head of the list
    Node<T>* tail;      // Points to the tail of the list
    int size;           // Number of elements in the list

public:
    DoublyLinkedList();                             // Constructor
    ~DoublyLinkedList();                            // Destructor
    void push_back(const T& data);                  // Add's an element to the end of the list
    bool remove(const T& data);                     // Removes specifc element from the list
    int getSize() const;                            // Get the size of the list
    T at(int index) const;                          // Find an elemente at a ceertain index
    bool contains(const T& data) const;             // Check if the list contains specific data
    void replace(int index, const T& newData);      // Replaces an elemenet at a specifc index
};

// Initializes an empty LinkedList
template <class T>
DoublyLinkedList<T>::DoublyLinkedList() : head(nullptr), tail(nullptr), size(0) 
{

}


template <class T>
DoublyLinkedList<T>::~DoublyLinkedList()
{
    // Traverses Linkedlist and deallocates memory for each node
    Node<T>* current = head;
    while (current != nullptr)
    {
        Node<T>* next = current->next;
        delete current;
        current = next;
    }
}

template <class T>
void DoublyLinkedList<T>::push_back(const T& data)
{
    Node<T>* newNode = new Node<T>(data);
    newNode->next = nullptr;

    // If the list is empty sets previous and next to null
    if (tail == nullptr)
    {
        newNode->previous = nullptr;
        head = newNode;
        tail = newNode;
    }
    else
    {
        newNode->previous = tail;
        tail->next = newNode;
        tail = newNode;
    }
    size++;     // Increments size to show new element added
}

template <class T>
bool DoublyLinkedList<T>::remove(const T& data)
{
    Node<T>* current = head;
    while (current != nullptr)
    {
        // Iterates through list to find element to remove
        if (current->data == data)
        {
            if (current == head)
            {
                head = current->next;
                if (head != nullptr)
                {
                    head->previous = nullptr;
                }
            }
            else
            {
                if (current->previous != nullptr)
                {
                    current->previous->next = current->next;
                }
                if (current->next != nullptr)
                {
                    current->next->previous = current->previous;
                }
            }

            if (current == tail)
            {
                tail = current->previous;
                if (tail != nullptr)
                {
                    tail->next = nullptr;
                }
            }
            
            delete current; // Frees the memory of removed item 
            size--;         // Decreases size to reflect removal
            return true;
        }
        current = current->next;
    }
    return false;
}

template <class T>
int DoublyLinkedList<T>::getSize() const
{
    return size;
}

template <class T>
T DoublyLinkedList<T>::at(int index) const
{
    // Checks to make sure that the index exissts
    if (index < 0 || index >= size)
    {
        throw std::out_of_range("Index out of range");
    }

    Node<T>* current = head;

    // Traverses the list to find the data  at the provided index
    for (int i = 0; i < index; i++)
    {
        current = current->next;
    }
    return current->data;
}

template <class T>
bool DoublyLinkedList<T>::contains(const T& data) const
{
    Node<T>* current = head;
    
    //Traverses the list
    while (current != nullptr)
    {
        if (current->data == data)
        {
            return true;
        }
        current = current->next;
    }
    return false;
}

template <class T>
void DoublyLinkedList<T>::replace(int index, const T& newData)
{
    // Ensures the index exists
    if (index < 0 || index >= size)
    {
        throw out_of_range("Index out of range");
    }

    Node<T>* current = head;
    // Traversese the list to search for index
    for (int i = 0; i < index; i++)
    {
        current = current->next;
    }
    
    // Replaces with new Data
    current->data = newData;
}

#endif
