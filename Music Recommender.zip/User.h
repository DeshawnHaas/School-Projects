/*
Name: User.h
Author: Deshawn Haas
Date: 12/3/2023
Description: This Usser class gathers information about a user. This inludes
an ID, a set of firends IDs, and a set of artists IDs. This User will be later
used in a recommender system.  It usis Recommender as a friend function so the recommender
can acees the sets in the user class.
*/
#ifndef USER_H
#define USER_H
#include <iostream>
#include <set>

class Recommender;

class User 
{
private:
    int id;
    set<int> friendIDs;
    set<int> artistIDs;

public:
    // Constructors
    User();          // Default constructor
    User(int _id);   // Parameterized constructor

    // Member Functions
    void addFriend(int friendID);
    void addArtist(int artistID);

    friend class Recommender;
};

// Default constructor
User::User() : id(0) 
{

}

// Parameterized constructor
User::User(int _id) : id(_id) 
{

}

// Member function to add a friend
void User::addFriend(int friendID) 
{
    friendIDs.insert(friendID);
}

// Member function to add an artist
void User::addArtist(int artistID) 
{
    artistIDs.insert(artistID);
}

#endif