/*
Name: Recommender.h
Author: Deshawn Haas
Date: 12/3/2023
Description: This Recommender class creates methods for loading data, listing friends, finding
common friends, listing artists listened to by users, and creating recommendations for 
other artists based on listening counts.
*/
#ifndef RECOMMENDER_H
#define RECOMMENDER_H

#include <iostream>
#include <fstream>
#include <sstream>
#include "Artist.h"
#include "HashMap.h"
#include "User.h"

using namespace std;

class Recommender 
{
private:
    HashMap<int, User, 10000> users;       // HashMap to store users' information
    HashMap<int, Artist, 10000> artists;   // HashMap to store artist information

    void loadArtists(const string& fileName);
    void loadUserFriends(const string& fileName);
    void loadUserArtists(const string& fileName);

public:
    // Constructor
    Recommender(const string& artistsFile, const string& userArtistsFile, const string& userFriendsFile);

    void listFriends(int userID);
    void commonFriends(int user1ID, int user2ID);
    void listArtists(int user1ID, int user2ID);
    void recommend(int userID, size_t top);

};

// Constructor that initializes the recommender with data files
Recommender::Recommender(const string& artistsFile, const string& userArtistsFile, const string& userFriendsFile) 
{
    loadArtists(artistsFile);
    loadUserFriends(userFriendsFile);
    loadUserArtists(userArtistsFile);
}

// Load artist data from a file into the artist map
void Recommender::loadArtists(const string& fileName) 
{
    ifstream file(fileName);
    int id;
    string line;
    string name;

    // Skip the first line (header) in the file
    getline(file, line);

    // Read artist information from each line and insert into the artists map
    while (getline(file, line)) 
    {
        istringstream iss(line);
        // Extract artist ID and name from the line
        if (iss >> id >> ws && getline(iss, name)) 
        {
            // Insert artist into the artists map with ID as the key
            artists.insert(id, Artist(id, name));
        } 
    }
}

// Load user-artist relationships from a file, updating the users map
void Recommender::loadUserArtists(const string& fileName) 
{
    ifstream file(fileName);
    int userID, artistID;
    string titleLine;

    // Skip the first line (header) in the file
    getline(file, titleLine);

    // Read user-artist relationships from each line and update the users map
    while (file >> userID >> artistID) 
    {
        // Check if the user already exists in the map
        if (users.contains(userID)) 
        {
            // Add the artist to the list of artists for the existing user
            users[userID].addArtist(artistID);
        }
    }
}

// Load user-friend relationships from a file, updating the users map
void Recommender::loadUserFriends(const string& fileName) 
{
    ifstream file(fileName);
    int userID, friendID;
    string titleLine;

    // Skip the first line (header) in the file
    getline(file, titleLine);

    // Read user-friend relationships from each line and update the users map
    while (file >> userID >> friendID) 
    {
        // If the user doesn't exist in the map, create a new user
        if (!users.contains(userID)) 
        {
            users.insert(userID, User(userID));
        }

        // Add the friend to the list of friends for the user
        users[userID].addFriend(friendID);
    }
}

// List all friends of a given user by their ID
void Recommender::listFriends(int userID) 
{
    if (users.contains(userID)) 
    {
        const User& user = users[userID];

        // Check if the user has friends
        if (!user.friendIDs.empty()) 
        {
            cout << "Friends of User " << userID << ":" << endl;

            // Print the ID of each friend
            for (int friendID : user.friendIDs) 
            {
                cout << friendID << endl;
            }
        } 
        else 
        {
            cout << "User " << userID << " has no friends." << endl;
        }
    } 
    else 
    {
        cout << "User not found." << endl;
    }
}

// Print common friends between two users
void Recommender::commonFriends(int user1ID, int user2ID) 
{
    if (users.contains(user1ID) && users.contains(user2ID)) 
    {
        const User& user1 = users[user1ID];
        const User& user2 = users[user2ID];
        bool foundCommonFriend = false;

        cout << "Common friends between User " << user1ID << " and User " << user2ID << ":" << endl;

        // Check for common friends and print their IDs
        for (int friendID1 : user1.friendIDs) 
        {
            for (int friendID2 : user2.friendIDs) 
            {
                if (friendID1 == friendID2) 
                {
                    cout << friendID1 << endl;
                    foundCommonFriend = true;
                }
            }
        }

        // If no common friends are found, indicate it
        if (!foundCommonFriend) 
        {
            cout << "No common friends found." << endl;
        }
    } 
    else 
    {
        cout << "One or both users not found." << endl;
    }
}

// List artists listened to by both specified users
void Recommender::listArtists(int user1ID, int user2ID) 
{
    if (users.contains(user1ID) && users.contains(user2ID)) 
    {
        const User& user1 = users[user1ID];
        const User& user2 = users[user2ID];

        cout << "Artists listened to by both User " << user1ID << " and User " << user2ID << ":" << endl;

        // Check for common artists and print their names
        for (int artistID1 : user1.artistIDs) 
        {
            for (int artistID2 : user2.artistIDs) 
            {
                if (artistID1 == artistID2) 
                {
                    const Artist& artist = artists[artistID1];
                    cout << artist.getName() << endl;
                }
            }
        }
    } 
    else 
    {
        cout << "One or both users not found." << endl;
    }
}

/* 
   Generate and print music artist recommendations for a given user, based on the 
   listening habits of the user and their friends. It limits the recommendations to the 
   top 'n' artists specified by the 'top' parameter 
*/
void Recommender::recommend(int userID, size_t top) 
{
    if (users.contains(userID)) 
    {
        const User& user = users[userID];
        HashMap<int, size_t, 10000> listenCounts;

        // Count the listens of the user
        for (int artistID : user.artistIDs) 
        {
            listenCounts[artistID]++;
        }

        // Count the listens from the user's friends
        for (int friendID : user.friendIDs) 
        {
            if (users.contains(friendID)) 
            {
                const User& friendUser = users[friendID];
                for (int artistID : friendUser.artistIDs) 
                {
                    listenCounts[artistID]++;
                }
            }
        }

        // Sort the artists by listen count in descending order
        auto sortedArtists = listenCounts.sortHashMapByValues();

        // Determine the number of recommendations to display
        size_t numRecommendations;
        if (sortedArtists.size() < top) 
        {
            numRecommendations = sortedArtists.size();
        } 
        else 
        {
            numRecommendations = top;
        }

        cout << "Recommendations for User " << userID << ":" << endl;

        // Print the top recommended artists along with their listen counts
        for (size_t i = 0; i < numRecommendations; ++i) 
        {
            int artistID = sortedArtists[i].first;
            size_t listenCount = sortedArtists[i].second;

            const Artist& artist = artists[artistID];

            cout << "Artist Name: " << artist.getName() << ", Listen Count: " << listenCount << endl;
        }
    } 
    else 
    {
        cout << "User not found." << endl;
    }
}

#endif
