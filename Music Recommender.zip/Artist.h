/*
Name: Artist.h
Author: Deshawn Haas
Date: 12/3/2023
Description: This artists class gathers information about a music artist, which includes
an id and a name. This will be used in a recommender system later on.
*/
#ifndef ARTIST_H
#define ARTIST_H

#include <string>

using namespace std;

class Artist 
{
private:
    int id;
    string name;

public:
    Artist();  // Default constructor
    Artist(int _id, string _name);  // Parameterized constructor

    // Getter and setters for id and name
    int getId() const;
    void setId(int _id);

    const string& getName() const;
    void setName(const string& _name);
};

// Default constructor
Artist::Artist() : id(0), name("") 
{
}

// Parameterized constructor
Artist::Artist(int _id, string _name) : id(_id), name(_name) 
{
}

// Getter and setter for id
int Artist::getId() const 
{
    return id;
}

void Artist::setId(int _id) 
{
    id = _id;
}

// Getter and setter for name
const string& Artist::getName() const 
{
    return name;
}

void Artist::setName(const string& _name) 
{
    name = _name;
}

#endif
