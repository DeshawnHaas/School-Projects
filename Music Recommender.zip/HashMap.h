/*
Name: HashMap.h
Author: Deshawn Haas
Date: 12/3/2023
Description: The file crates a template HashMap class that supports operations such as 
insertion, retrieavl, removal, checking for keys, and sorting. It usees a vector 
of linked lists to represent the table where each lists holds a key value.
*/
#ifndef HASH_MAP_H
#define HASH_MAP_H
#include <vector>
#include <list>
using namespace std;


template <typename K, typename V>
struct HashEntry 
{
    K key;
    V value;
};

template <typename K, typename V, size_t TableSize>
class HashMap
{
private:
    vector<list<HashEntry<K, V>>> table;

public:
    HashMap();
    void insert(const K& key, const V& value);
    bool get(const K& key, V& value) const;
    V& operator[](const K& key);
    void remove(const K& key);
    bool contains(const K& key);
    vector<pair<K, V>> sortHashMapByValues();
};

// Constructor
template <typename K, typename V, size_t TableSize>
HashMap<K, V, TableSize>::HashMap() : table(TableSize) 
{

}

// Inserts a key-value pair into the hash map
template <typename K, typename V, size_t TableSize>
void HashMap<K, V, TableSize>::insert(const K& key, const V& value) 
{
    size_t index = hash<K>{}(key) % TableSize; // Calculate the index using the hash function
    table[index].push_back({key, value});      // Add the entry to the linked list at the calculated index
}

// Retrieves the value associated with a given key
template <typename K, typename V, size_t TableSize>
bool HashMap<K, V, TableSize>::get(const K& key, V& value) const 
{
    size_t index = hash<K>{}(key) % TableSize; // Calculate the index using the hash function
    for (const auto& entry : table[index]) {
        if (entry.key == key) {
            value = entry.value;
            return true; // Key found
        }
    }
    return false; // Key not found
}

// Provides access to the value associated with a key, allowing for both retrieval and insertion
template <typename K, typename V, size_t TableSize>
V& HashMap<K, V, TableSize>::operator[](const K& key) 
{
    size_t index = hash<K>{}(key) % TableSize; // Calculate the index using the hash function
    for (auto& entry : table[index]) {
        if (entry.key == key) {
            return entry.value; // Key found
        }
    }
    // Key not found, insert a default value
    table[index].push_back({key, V{}});
    return table[index].back().value;
}

// Removes a key-value pair from the hash map
template <typename K, typename V, size_t TableSize>
void HashMap<K, V, TableSize>::remove(const K& key) 
{
    size_t index = hash<K>{}(key) % TableSize; // Calculate the index using the hash function
    table[index].remove_if([key](const HashEntry<K, V>& entry) 
    {
        return entry.key == key;
    });
}

// Checks if a key is present in the hash map
template <typename K, typename V, size_t TableSize>
bool HashMap<K, V, TableSize>::contains(const K& key) 
{
    size_t index = hash<K>{}(key) % TableSize; // Calculate the index using the hash function
    for (const auto& entry : table[index]) 
    {
        if (entry.key == key) 
        {
            return true; // Key found
        }
    }
    return false; // Key not found
}

// Sorts the key-value pairs based on the values in descending order and returns a vector of sorted pairs
template <typename K, typename V, size_t TableSize>
vector<pair<K, V>> HashMap<K, V, TableSize>::sortHashMapByValues() 
{
    vector<pair<K, V>> result;
    for (const auto& bucket : table)
    {
        for (const auto& entry : bucket) 
        {
            result.push_back({entry.key, entry.value});
        }
    }

    // Custom sorting function (bubble sort)
    for (size_t i = 0; i < result.size() - 1; ++i) 
    {
        for (size_t j = 0; j < result.size() - i - 1; ++j) 
        {
            if (result[j].second < result[j + 1].second) 
            {
                swap(result[j], result[j + 1]);
            }
        }
    }

    return result;
}

#endif