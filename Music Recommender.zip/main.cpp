/*
Name: main.cpp
Author: Deshawn Haas
Date: 12/3/2023
Description: This file contains the main function for a simple music recommendation system demonstration.
It and provides a menu for the user to interact with various features such as listing friends, 
finding common friends, listing artists, and receiving music recommendations.
*/

#include "Recommender.h"

int main()
{
    // File names for artists, user artists, and user friends
    string artistsFile = "artists.dat";
    string userArtistsFile = "user_artists.dat";
    string userFriendsFile = "user_friends.dat";
    
    // Create a Recommender object with the provided files
    Recommender recommender(artistsFile, userArtistsFile, userFriendsFile);

    // Main loop for user interaction
    while (true)
    {
        int choice;
    
        // Display menu options
        cout << "Choose an action:" << endl;
        cout << "1. List Friends" << endl;
        cout << "2. Common Friends" << endl;
        cout << "3. List Artists" << endl;
        cout << "4. Recommend" << endl;
        cout << "0. Exit" << endl;

        // Get user's choice
        cin >> choice;

        // Exit the loop if the user chooses 0
        if (choice == 0)
        {
            break;
        }

        int userID1, userID2, top;

        switch (choice)
        {
            case 1:
                // List Friends option
                cout << "Enter User ID: ";
                cin >> userID1;
                recommender.listFriends(userID1);
                break;

            case 2:
                // Common Friends option
                cout << "Enter User ID 1: ";
                cin >> userID1;
                cout << "Enter User ID 2: ";
                cin >> userID2;
                recommender.commonFriends(userID1, userID2);
                break;

            case 3:
                // List Artists option
                cout << "Enter User ID 1: ";
                cin >> userID1;
                cout << "Enter User ID 2: ";
                cin >> userID2;
                recommender.listArtists(userID1, userID2);
                break;

            case 4:
                // Recommend option
                cout << "Enter User ID: ";
                cin >> userID1;
                cout << "Enter the number of recommendations: ";
                cin >> top;
                recommender.recommend(userID1, top);
                break;

            default:
                // Invalid option
                cout << "Invalid action." << endl;
        }
    }

    return 0;
}
