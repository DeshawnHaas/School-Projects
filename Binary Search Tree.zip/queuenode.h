// Name: queuenode.h
// Author: Deshawn Haas
// Date: 11/19/2023
/* Description: This file implements a queue using templates. It is implemented as a linked list where the nodes hole the template data type.
It provides operations such as enqueue, dequeue, and is empty. */
#ifndef queue_node_h
#define queue_node_h

#include <iostream>
#include <fstream>
#include <memory>
using namespace std;


template <typename T>
struct QueueNode 
{
    T data; // Node data
    shared_ptr<QueueNode<T>> next;  // Pointer to next node
    QueueNode(T val) : data(val), next(nullptr) {}  // Constructor for node w/ given value
};


template <typename T>
class Queue 
{
    private:
        shared_ptr<QueueNode<T>> front; // Pointer to front of the queue
        shared_ptr<QueueNode<T>> rear;  // Pointer to rear

    public:
        Queue(); // constructor
        void enqueue(T val);    //Add item to queue
        T dequeue();    // Remove from queue and return value
        bool isEmpty() const;   // Check if queue is empty


};

// Intilizes queue with front and rear to null
template <typename T>
Queue<T>::Queue() : front(nullptr), rear(nullptr) 
{
    
}

template <typename T>
void Queue<T>::enqueue(T val) 
{
    auto newNode = make_shared<QueueNode<T>>(val);
    // If queue is empty new node becomes front and rear
    if (!front) 
    {
        front = rear = newNode;
    } 
    // Add new node to rear
    else 
    {
        rear->next = newNode;
        rear = newNode;
    }

}

template <typename T>
T Queue<T>::dequeue() 
{
    // Throws exception if queue isempty
    if (!front) 
    {
        throw runtime_error("Queue is empty");
    }
    T val = front->data;
    front = front->next;
    // If queue is now empty update the rear to nul
    if (!front) 
    {
        rear = nullptr;
    }

    return val;
}

template <typename T>
bool Queue<T>::isEmpty() const 
{
 
    return !front;
}
#endif