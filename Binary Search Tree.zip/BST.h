// Name: BST.h
// Author: Deshawn Haas
// Date: 11/19/2023
/* Description: This file deines a Binary search tree using templates. It uses nodes and a queue for traversal.
It supports insertion, serialization, deserialization, searching and displaying. */
#ifndef BST_H
#define BST_H

#include "queuenode.h"
#include <iostream>
#include <fstream>

using namespace std;


template <typename T>
struct BSTreeNode 
{
    T data;  // Data of the node
    shared_ptr<BSTreeNode<T>> left;   // Pointer to the left child
    shared_ptr<BSTreeNode<T>> right;  // Pointer to the right child

    // Constructor to initialize empty node
    BSTreeNode(T val) : data(val), left(nullptr), right(nullptr) {}
};

template <typename T>
class BST 
{
private:
    shared_ptr<BSTreeNode<T>> root;  // Pointer to the root of the tree
    Queue<shared_ptr<BSTreeNode<T>>> levelOrderQueue; // Queue being used for level-order traversal
    void serializeLevelOrder(ostream& os, shared_ptr<BSTreeNode<T>> node);  // Helper function to serialize the BST in level order
    void deserializeLevelOrder(ifstream& inFile, shared_ptr<BSTreeNode<T>>& node);  // Helper function to deserialize the BST from a file

public:
    BST();  // Constructor
    ~BST();  // Destructor
    void destroyTree(shared_ptr<BSTreeNode<T>>& node);  // Created to delete nodes for destructor
    void insert(T val); // Insert a value into the BST
    void saveToFile(const string& filename = "bst_serialized.txt"); // Save the BST to a file in a serialized format
    void loadFromFile(const string& filename);  // Load the BST from a file in a serialized format
    bool search(T val); // Search for a value in the BST
    void displayPreOrder(); // Display the BST in PreOrder traversal
};

// Constructor initalizes root to null
template <typename T>
BST<T>::BST() : root(nullptr) 
{

}

template <typename T>
BST<T>::~BST() 
{
    // Call a recursive function to delete nodes starting from root
    destroyTree(root);
}

template <typename T>
void BST<T>::destroyTree(shared_ptr<BSTreeNode<T>>& node) 
{
    if (node) 
    {
        destroyTree(node->left);
        destroyTree(node->right);
        node.reset();
    }
}

template <typename T>
void BST<T>::insert(T val) 
{
    // If the tree is empty, create a new node as root
    if (!root) 
    {
        root = make_shared<BSTreeNode<T>>(val);
        return;
    }

    shared_ptr<BSTreeNode<T>> current = root;
    while (current) 
    {   
        // Traverese to the left if is less than the current node data
        if (val < current->data) 
        {
            // If left child is null create a new wnode
            if (!current->left) 
            {
                current->left = make_shared<BSTreeNode<T>>(val);
                return;
            }
            current = current->left;
        } 
        // Travers to the right if val is creater than current node data
        else if (val > current->data) 
        {
            // If right child is null create a new node
            if (!current->right) 
            {
                current->right = make_shared<BSTreeNode<T>>(val);
                return;
            }
            current = current->right;
        } 
        // In case of a duplicate value
        else 
        {
            return;
        }
    }
}


template <typename T>
void BST<T>::saveToFile(const string& filename) 
{
    // Opens outputfile stream
    ofstream outFile(filename);
    if (outFile.is_open()) 
    {
        // Peforms level-order travels adn serializes
        serializeLevelOrder(outFile, root);
        // Closes the stream
        outFile.close();
        cout << "BST serialized and saved to file successfully." << endl;
    } 
    else 
    {
        cout << "Error: Unable to open file for serialization." << endl;
    }
}


template <typename T>
void BST<T>::loadFromFile(const string& filename) 
{
    // Opens input file stream
    ifstream inFile(filename);
    if (inFile.is_open()) 
    {
        // Deseralizes the BST from the file
        deserializeLevelOrder(inFile, root);
        //Closes file stream
        inFile.close();
        cout << "BST deserialized from file successfully." << endl;
    } 
    else 
    {
        cout << "Error: Unable to open file for deserialization." << endl;
    }
}


template <typename T>
bool BST<T>::search(T val) 
{
    shared_ptr<BSTreeNode<T>> current = root;
    while (current) 
    {
        if (val == current->data) 
        {
            cout << "Search result: found" << endl;
            return true;
        } 
        // Traverses to the left if less than current node
        else if (val < current->data) 
        {
            current = current->left;
        } 
        // Traverses to the right if greater than 
        else 
        {
            current = current->right;
        }
    }
    // Returns false if loop is complete without finding data
    cout << "Search result: not found" << endl;
    return false;
}


template <typename T>
void BST<T>::displayPreOrder() 
{
    cout << "PreOrder: ";
    // Calls serial order to output level order display
    serializeLevelOrder(cout, root);
    cout << endl;
}





template <typename T>
void BST<T>::serializeLevelOrder(ostream& os, shared_ptr<BSTreeNode<T>> node) 
{
    // Initialies queue
    levelOrderQueue.enqueue(node);
    //Level order traversal
    while (!levelOrderQueue.isEmpty()) 
    {   
        //Dequeues node from front 
        auto current = levelOrderQueue.dequeue();
        // If null output #
        if (!current) 
        {
            os << "# ";
        } 
        // If it has data output it and enqueue the left and right children
        else 
        {
            os << current->data << " ";
            levelOrderQueue.enqueue(current->left);
            levelOrderQueue.enqueue(current->right);
        }
    }
}


template <typename T>
void BST<T>::deserializeLevelOrder(ifstream& inFile, shared_ptr<BSTreeNode<T>>& node) 
{
    // Initiates queue
    levelOrderQueue.enqueue(node);
    // Level order traversal
    while (!levelOrderQueue.isEmpty()) 
    {
        // Deequeues front node
        auto current = levelOrderQueue.dequeue();
        T val;
        // Reads values from file
        inFile >> val;
        // If the value is not a null node update current and enqueue the children
        if (val != -1) 
        { // -1 represents a null node
            current->data = val;
            current->left = make_shared<BSTreeNode<T>>(0);
            current->right = make_shared<BSTreeNode<T>>(0);
            levelOrderQueue.enqueue(current->left);
            levelOrderQueue.enqueue(current->right);
        }
    }
}

#endif